# pg-docker-custom

## Projeto de exemplo mostrando como lançar um Postgresql usando Docker e docker-compose.
Um diferencial é a possibilidade de customizar as configuracoes do pg através do postgresql.conf

### Link do vídeo no Youtube mostrando o uso desse projeto na prática:
https://youtu.be/Qzfb3yx2OI4
